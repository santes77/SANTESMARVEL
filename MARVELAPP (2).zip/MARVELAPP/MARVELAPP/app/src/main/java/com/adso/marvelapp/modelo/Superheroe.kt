package com.adso.marvelapp.modelo

data class Superheroe (
    var nombre:String,
    var publisher: String,
    var nombreReal: String,
    var foto: String
)